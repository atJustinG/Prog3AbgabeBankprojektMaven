package bankprojekt;
import org.junit.jupiter.api.Test;


/**
 * Unit test for simple App.
 */
public class AppTest 
{
    @Test
    public void myTest(){

    }

}
